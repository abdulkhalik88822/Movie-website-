<p align="center"><img src="https://github.com/divasharma3/nxmovix/assets/99474387/e7f2cfbc-0700-4deb-a45d-4b31ca375136" width="150"></p>
<h1 align="center"><b>NXMovix</b></h1>

 # Preview
![Screenshot 2023-10-05 180748](https://github.com/divasharma3/nxmovix/assets/99474387/57ddca02-971e-4341-a906-aec811c66005)
